package com.example.homebudget;

import java.util.prefs.Preferences;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Window;

public class FontManager {
    private static String currentFont = "System";
    private static final Preferences prefs = Preferences.userNodeForPackage(FontManager.class);

    static {
        currentFont = prefs.get("appFont", "System");
    }

    public static void setGlobalFont(String fontName) {
        currentFont = fontName;
        prefs.put("appFont", fontName);
        updateAllWindows();
    }

    public static String getCurrentFont() {
        return currentFont;
    }

    public static void applyFontToScene(Scene scene) {
        if (scene != null) {
            scene.getRoot().setStyle("-fx-font-family: '" + currentFont + "';");
        }
    }

    private static void updateAllWindows() {
        for (Window window : Window.getWindows()) {
            if (window instanceof Stage) {
                applyFontToScene(((Stage) window).getScene());
            }
        }
    }
}