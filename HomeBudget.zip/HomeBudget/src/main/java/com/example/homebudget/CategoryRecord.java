package com.example.homebudget;

public class CategoryRecord {
    private String categoryName;

    public CategoryRecord(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryName() {
        return categoryName;
    }
}