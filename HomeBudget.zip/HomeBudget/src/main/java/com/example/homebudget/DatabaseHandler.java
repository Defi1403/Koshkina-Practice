package com.example.homebudget;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;

public class DatabaseHandler extends Configs {
    private Connection dbConnection;

    public Connection getDbConnection() throws SQLException, ClassNotFoundException {
        String connectionString = "jdbc:mysql://" + dbHost + ":" + dbPort + "/" + dbName;
        Class.forName("com.mysql.cj.jdbc.Driver");
        dbConnection = DriverManager.getConnection(connectionString, dbUser, dbPass);
        return dbConnection;
    }

    public int regUser(User user) {
        String insert = "INSERT INTO Users (user_name, login, password, email) VALUES (?, ?, ?, ?)";

        try (Connection connection = getDbConnection();
             PreparedStatement prSt = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS)) {

            prSt.setString(1, user.getUserName());
            prSt.setString(2, user.getLogin());
            prSt.setString(3, user.getPassword());
            prSt.setString(4, user.getEmail());
            prSt.executeUpdate();

            try (ResultSet rs = prSt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    // Авторизация пользователя
    public User getUser(String login, String password) {
        String select = "SELECT * FROM Users WHERE login = ? AND password = ?";

        try (Connection connection = getDbConnection();
             PreparedStatement prSt = connection.prepareStatement(select)) {

            prSt.setString(1, login);
            prSt.setString(2, password);

            try (ResultSet resSet = prSt.executeQuery()) {
                if (resSet.next()) {
                    return new User(
                            resSet.getInt("user_id"),
                            resSet.getString("user_name"),
                            resSet.getString("login"),
                            resSet.getString("password"),
                            resSet.getString("email")
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void addCategory(String categoryName) {
        String insert = "INSERT INTO Categories (category_name) VALUES (?)";
        try (Connection connection = getDbConnection();
             PreparedStatement prSt = connection.prepareStatement(insert)) {
            prSt.setString(1, categoryName);
            prSt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<String> getCategories() {
        ObservableList<String> categories = FXCollections.observableArrayList();
        String select = "SELECT category_name FROM Categories";

        try (Connection connection = getDbConnection();
             PreparedStatement prSt = connection.prepareStatement(select);
             ResultSet rs = prSt.executeQuery()) {

            while (rs.next()) {
                categories.add(rs.getString("category_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return categories;
    }

    public void addExpense(int userId, double amount, String categoryName, Date date) {
        String insert = "INSERT INTO Expense (user_id, amount, date, category_name) VALUES (?, ?, ?, ?)";
        executeInsert(insert, userId, amount, date, categoryName);
    }

    public void addIncome(int userId, double amount, String categoryName, Date date) {
        String insert = "INSERT INTO Income (user_id, amount, date, category_name) VALUES (?, ?, ?, ?)";
        executeInsert(insert, userId, amount, date, categoryName);
    }

    private void executeInsert(String query, int userId, double amount, Date date, String categoryName) {
        try (Connection connection = getDbConnection();
             PreparedStatement prSt = connection.prepareStatement(query)) {
            prSt.setInt(1, userId);
            prSt.setDouble(2, amount);
            prSt.setDate(3, date);
            prSt.setString(4, categoryName);
            prSt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}