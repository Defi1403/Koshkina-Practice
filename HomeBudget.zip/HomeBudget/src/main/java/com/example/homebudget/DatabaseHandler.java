package com.example.homebudget;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class DatabaseHandler extends Configs {
    // Объявление класса DatabaseHandler, который наследует настройки из класса Configs.

    Connection dbConnection;
    // Объявление переменной dbConnection типа Connection для установки соединения с базой данных.

    public Connection getDbConnection()
            throws ClassNotFoundException, SQLException {
        // Метод getDbConnection, который возвращает объект Connection для работы с базой данных,
        // выбрасывает исключения ClassNotFoundException и SQLException при необходимости.

        String connectionString = "jdbc:mysql://" + dbHost + ":"
                + dbPort + "/" + dbName;
        // Формирование строки подключения к базе данных, используя параметры хоста, порта и имени базы данных.

        Class.forName("com.mysql.cj.jdbc.Driver");
        // Загрузка JDBC-драйвера MySQL, необходимого для работы с базой данных.

        dbConnection = DriverManager.getConnection(connectionString,
                dbUser, dbPass);
        // Установка соединения с базой данных, используя строку подключения, а также имя пользователя и пароль.

        return dbConnection;
        // Возвращение объекта Connection, который можно использовать для выполнения SQL-запросов.
    }
    public void regUser(User user) {
        // Метод regUser, который принимает объект User и добавляет его в базу данных.

        String insert = "INSERT INTO " + Const.USER_TABLE + "(" +
                Const.USER_NAME + "," + Const.USER_LOGIN + "," +
                Const.USER_PASSWORD + "," + Const.USER_EMAIL + ") "  +
                "VALUES(?, ?, ?, ?)";
        // Создаем SQL-запрос для вставки нового пользователя в таблицу.
        // Конкретные значения полей будут заменены на параметры (?).

        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(insert);
            // Получаем соединение с базой данных и создаем объект PreparedStatement
            // для выполнения подготовленного SQL-запроса.

            prSt.setString(1, user.getUserName());
            // Устанавливаем значение первого параметра в запросе на имя пользователя, полученное из объекта User.

            prSt.setString(2, user.getLogin());
            // Устанавливаем значение второго параметра на логин пользователя, полученный из объекта User.

            prSt.setString(3, user.getPassword());
            // Устанавливаем значение третьего параметра на пароль пользователя, полученный из объекта User.

            prSt.setString(4, user.getEmail());
            // Устанавливаем значение четвертого параметра на электронную почту пользователя, полученную из объекта User.

            prSt.executeUpdate();
            // Выполняем подготовленный запрос, который добавляет нового пользователя в базу данных.
        } catch (SQLException e) {
            throw new RuntimeException(e);
            // Обрабатываем исключения SQL, выбрасывая RuntimeException в случае возникновения ошибок.

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
            // Обрабатываем исключение ClassNotFoundException на случай, если не удастся найти класс драйвера базы данных,
            // выбрасывая также RuntimeException.
        }
    }

    public ResultSet getUser(User user) {
        // Метод getUser, который принимает объект User и возвращает ResultSet с результатами выборки пользователя из базы данных.

        ResultSet resSet = null;
        // Объявление переменной resSet для хранения результата выборки.

        String select = "SELECT * FROM " + Const.USER_TABLE + " WHERE " +
                Const.USER_LOGIN + " = ? AND " + Const.USER_PASSWORD + " = ?";
        // Формирование SQL-запроса для выборки пользователя из таблицы по логину и паролю.
        // Используем параметры (?), чтобы избежать SQL-инъекций.

        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(select);
            // Получаем соединение с базой данных и создаем объект PreparedStatement для выполнения SQL-запроса.

            prSt.setString(1, user.getLogin());
            // Устанавливаем значение первого параметра на логин пользователя, полученный из объекта User.

            prSt.setString(2, user.getPassword());
            // Устанавливаем значение второго параметра на пароль пользователя, полученный из объекта User.

            resSet = prSt.executeQuery();
            // Выполняем запрос и сохраняем результаты выборки в переменной resSet.
        } catch (SQLException e) {
            throw new RuntimeException(e);
            // Обрабатываем исключения SQL, выбрасывая RuntimeException в случае ошибок.
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
            // Обрабатываем исключение ClassNotFoundException на случай, если не удастся найти класс драйвера базы данных,
            // выбрасывая также RuntimeException.
        }

        return resSet;
        // Возвращаем ResultSet с результатами выборки. Если пользователя не существует, вернется пустой ResultSet.
    }
}

