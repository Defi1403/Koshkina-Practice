package com.example.homebudget;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public  class RegistrationController{

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField email_field;

    @FXML
    private TextField login_field;

    @FXML
    private TextField name_field;

    @FXML
    private PasswordField password_field;

    @FXML
    private Button authTextButton;

    @FXML
    private Button сontinueButton;

    private void regNewUser() {
        // Объявление метода regNewUser, который не принимает параметров и не возвращает значения.

        DatabaseHandler dbHandler = new DatabaseHandler();
        // Создаем новый экземпляр класса DatabaseHandler, который обеспечивает взаимодействие с базой данных.

        User user = new User(name_field.getText(), login_field.getText(),
                password_field.getText(), email_field.getText());
        // Создаем нового пользователя (объект класса User),
        // передавая в его конструктор данные из текстовых полей:
        // имя (name_field), логин (login_field), пароль (password_field) и email (email_field).

        dbHandler.regUser(user);
        // Вызываем метод regUser объекта dbHandler для регистрации нового пользователя в базе данных, передавая ему объект user.
    }

    @FXML
    void initialize() {
        сontinueButton.setOnAction(actionEvent -> {
            regNewUser();
            сontinueButton.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("main-menu.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
        authTextButton.setOnAction(actionEvent -> {
            authTextButton.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("authorization.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }
}
