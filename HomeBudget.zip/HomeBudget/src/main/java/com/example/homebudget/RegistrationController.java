package com.example.homebudget;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public  class RegistrationController{

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField email_field;

    @FXML
    private TextField login_field;

    @FXML
    private TextField name_field;

    @FXML
    private PasswordField password_field;

    @FXML
    private Button authTextButton;

    @FXML
    private Button сontinueButton;

    private void regNewUser() {
        DatabaseHandler dbHandler = new DatabaseHandler();

        // Создаем пользователя с временным userId = 0
        // (реальный ID будет присвоен при сохранении в БД)
        User user = new User(
                0, // Временный ID
                name_field.getText().trim(),
                login_field.getText().trim(),
                password_field.getText().trim(),
                email_field.getText().trim()
        );

        // Регистрируем пользователя и получаем его реальный ID из БД
        int userId = dbHandler.regUser(user);

        if (userId != -1) {
            // Обновляем пользователя с реальным ID
            user.setId(userId);
            // Сохраняем текущего пользователя
            AuthorizationController.setCurrentUser(user);
        } else {
            System.out.println("Ошибка при регистрации пользователя");
        }
    }

    @FXML
    void initialize() {
        сontinueButton.setOnAction(actionEvent -> {
            regNewUser();
            сontinueButton.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("main-menu.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        сontinueButton.setOnAction(actionEvent -> {
            regNewUser();
            String nameText = name_field.getText().trim();
            String loginText = login_field.getText().trim();
            String passwordText = password_field.getText().trim();
            String emailText = email_field.getText().trim();

            // Проверка заполнения полей
            if (loginText.isEmpty() || passwordText.isEmpty() || nameText.isEmpty() || emailText.isEmpty()) {
                System.out.println("[VALIDATION] Ошибка: поля имени, логина, пароля и почты обязательны");
                return;
            }

            // Проверка учетных данных
            try {
                // Закрытие текущего окна
                Stage currentStage = (Stage) сontinueButton.getScene().getWindow();
                currentStage.close();

                // Открытие главного меню
                FXMLLoader loader = new FXMLLoader(getClass().getResource("main-menu.fxml"));
                Parent root = loader.load();
                Stage newStage = new Stage();
                newStage.setScene(new Scene(root));
                newStage.show();
            } catch (IOException e) {
                System.err.println("[ERROR] Ошибка при загрузке main-menu.fxml: " + e.getMessage());
            }

        });

        authTextButton.setOnAction(actionEvent -> {
            System.out.println("[NAVIGATION] Переход к авторизации");
            try {
                Stage currentStage = (Stage) authTextButton.getScene().getWindow();
                currentStage.close();

                Parent root = FXMLLoader.load(getClass().getResource("authorization.fxml"));
                Stage newStage = new Stage();
                newStage.setScene(new Scene(root));
                newStage.show();
            } catch (IOException e) {
                System.err.println("[ERROR] Ошибка при загрузке authorization.fxml: " + e.getMessage());
            }
        });
    }
}
