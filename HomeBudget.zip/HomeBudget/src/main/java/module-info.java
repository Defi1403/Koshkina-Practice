module com.example.homebudget {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.prefs;


    opens com.example.homebudget to javafx.fxml;
    exports com.example.homebudget;
}